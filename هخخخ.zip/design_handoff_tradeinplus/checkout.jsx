/* checkout.jsx — "Trade In Plus" checkout gateway.
   3-step flow (Shipping → Payment → Confirm) + sticky order summary.
   Same identity as the PDP. Responsive via container queries.
   Exports window.CheckoutFlow */

(function () {
  const css = `
  .ckt{container-type:inline-size;background:#fff;color:#1d1d1f;
    font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Arial,sans-serif;
    -webkit-font-smoothing:antialiased;line-height:1.5;min-height:100%;
    --ink:#1d1d1f;--gray:#6e6e73;--faint:#86868b;--line:#e5e5e8;--stage:#f5f5f7;--shot:#fdfdfd;
    --blue:#0071e3;--green:#1a8a4a}
  .ckt *{box-sizing:border-box;margin:0;padding:0}
  .ckt button,.ckt input,.ckt select,.ckt textarea{font-family:inherit}
  .ckt input,.ckt textarea,.ckt select{font-size:15px;color:var(--ink)}

  /* top bar */
  .ck-top{display:flex;align-items:center;justify-content:space-between;height:60px;padding:0 32px;
    border-bottom:1px solid var(--line)}
  .ck-brand{display:flex;align-items:center;gap:9px;font-weight:800;font-size:18px;letter-spacing:-.02em}
  .ck-brand .mk{width:26px;height:26px;border-radius:7px;background:var(--ink);color:#fff;display:flex;
    align-items:center;justify-content:center;font-size:13px;font-weight:800}
  .ck-secure{display:flex;align-items:center;gap:7px;font-size:12.5px;color:var(--faint);font-weight:500}

  /* stepper */
  .ck-steps{display:flex;align-items:center;justify-content:center;gap:0;padding:26px 32px 6px}
  .ck-step{display:flex;align-items:center;gap:11px}
  .ck-step .num{width:30px;height:30px;border-radius:50%;border:1.5px solid var(--line);display:flex;
    align-items:center;justify-content:center;font-size:13px;font-weight:700;color:var(--faint);
    background:#fff;transition:all .25s;flex:0 0 auto}
  .ck-step .lab{font-size:14px;font-weight:600;color:var(--faint);transition:color .25s}
  .ck-step.active .num{border-color:var(--ink);background:var(--ink);color:#fff}
  .ck-step.active .lab{color:var(--ink)}
  .ck-step.done .num{border-color:var(--green);background:var(--green);color:#fff}
  .ck-step.done .lab{color:var(--ink)}
  .ck-bar{width:64px;height:1.5px;background:var(--line);margin:0 16px;position:relative;overflow:hidden}
  .ck-bar i{position:absolute;inset:0;background:var(--green);transform:scaleX(0);transform-origin:right;transition:transform .35s}
  .ck-bar.fill i{transform:scaleX(1)}

  /* layout */
  .ck-main{display:grid;grid-template-columns:1fr 400px;gap:40px;max-width:1140px;margin:0 auto;
    padding:30px 32px 64px;align-items:start}
  .ck-pane{min-width:0}
  .ck-h2{font-size:24px;font-weight:800;letter-spacing:-.02em;direction:rtl;text-align:right}
  .ck-hint{direction:rtl;text-align:right;color:var(--gray);font-size:14px;margin-top:4px}

  /* form */
  .ck-form{margin-top:24px;display:grid;grid-template-columns:1fr 1fr;gap:16px}
  .ck-field{display:flex;flex-direction:column;gap:7px;direction:rtl}
  .ck-field.full{grid-column:1/-1}
  .ck-field label{font-size:13px;font-weight:600;color:var(--gray)}
  .ck-field label .req{color:#d8412f}
  .ck-input{height:50px;border:1px solid var(--line);border-radius:13px;padding:0 15px;background:#fff;
    direction:rtl;transition:border-color .15s,box-shadow .15s;width:100%}
  textarea.ck-input{height:86px;padding:13px 15px;resize:none;line-height:1.5}
  .ck-input::placeholder{color:#b8b8bd}
  .ck-input:focus{outline:none;border-color:var(--ink);box-shadow:0 0 0 3px rgba(0,0,0,.06)}
  .ck-input:focus-visible{outline:none}
  select.ck-input{appearance:none;cursor:pointer;
    background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%236e6e73' stroke-width='2' stroke-linecap='round'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
    background-repeat:no-repeat;background-position:left 15px center}

  /* payment methods */
  .ck-pays{margin-top:24px;display:flex;flex-direction:column;gap:12px}
  .ck-pay{border:1px solid var(--line);border-radius:16px;overflow:hidden;transition:border-color .15s,box-shadow .15s}
  .ck-pay.on{border-color:var(--ink);box-shadow:0 0 0 1px var(--ink)}
  .ck-pay-hd{display:flex;align-items:center;gap:14px;padding:16px 18px;cursor:pointer;direction:rtl}
  .ck-radio{width:20px;height:20px;border-radius:50%;border:1.5px solid #c5c5cb;flex:0 0 auto;position:relative;transition:border-color .15s}
  .ck-pay.on .ck-radio{border-color:var(--ink)}
  .ck-pay.on .ck-radio::after{content:"";position:absolute;inset:4px;border-radius:50%;background:var(--ink)}
  .ck-pay-ic{width:42px;height:42px;border-radius:11px;background:var(--stage);display:flex;align-items:center;
    justify-content:center;color:var(--ink);flex:0 0 auto}
  .ck-pay-tx{flex:1;min-width:0}
  .ck-pay-tx .t{font-weight:600;font-size:15.5px}
  .ck-pay-tx .d{font-size:12.5px;color:var(--gray);margin-top:2px}
  .ck-pay-badge{font-size:11px;font-weight:700;color:var(--green);background:rgba(26,138,74,.1);
    padding:4px 9px;border-radius:7px;letter-spacing:.02em}
  .ck-pay-body{max-height:0;overflow:hidden;transition:max-height .3s ease;direction:rtl}
  .ck-pay.on .ck-pay-body{max-height:340px}
  .ck-pay-inner{padding:0 18px 18px 18px;border-top:1px solid var(--line);margin-top:0;padding-top:16px}

  .ck-walletfields{display:grid;grid-template-columns:1fr;gap:12px}
  .ck-note{display:flex;gap:10px;align-items:flex-start;background:var(--stage);border-radius:12px;
    padding:12px 14px;font-size:13px;color:var(--gray);line-height:1.5}
  .ck-note .ic{color:var(--ink);flex:0 0 auto;margin-top:1px}

  /* installment plans */
  .ck-plans{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
  .ck-plan{border:1px solid var(--line);border-radius:13px;padding:13px 12px;background:#fff;cursor:pointer;
    text-align:center;transition:border-color .15s,box-shadow .15s}
  .ck-plan:hover{border-color:#bcbcc2}
  .ck-plan.on{border-color:var(--ink);box-shadow:0 0 0 1px var(--ink)}
  .ck-plan .mo{font-weight:800;font-size:18px}
  .ck-plan .mo span{font-size:12px;font-weight:600;color:var(--gray)}
  .ck-plan .per{font-size:12.5px;color:var(--blue);font-weight:700;margin-top:5px;direction:ltr}
  .ck-provs{display:flex;gap:8px;margin-top:14px;flex-wrap:wrap}
  .ck-prov{font-size:12px;font-weight:700;color:var(--ink);border:1px solid var(--line);border-radius:8px;
    padding:6px 11px;cursor:pointer;transition:all .15s;background:#fff}
  .ck-prov.on{background:var(--ink);color:#fff;border-color:var(--ink)}

  /* nav buttons */
  .ck-nav{display:flex;gap:12px;margin-top:30px}
  .ck-btn{display:flex;align-items:center;justify-content:center;gap:9px;height:54px;border-radius:14px;
    font-size:16px;font-weight:600;cursor:pointer;transition:transform .12s,background .15s,color .15s,opacity .15s}
  .ck-btn:active{transform:scale(.985)}
  .ck-btn.primary{flex:1;background:var(--ink);color:#fff;border:1px solid var(--ink)}
  .ck-btn.primary:hover{background:#000}
  .ck-btn.ghost{background:#fff;color:var(--ink);border:1px solid var(--line);padding:0 22px}
  .ck-btn.ghost:hover{background:var(--stage)}

  /* review (confirm step) */
  .ck-rev{margin-top:24px;display:flex;flex-direction:column;gap:14px}
  .ck-revcard{border:1px solid var(--line);border-radius:16px;padding:18px;direction:rtl}
  .ck-revcard .rh{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
  .ck-revcard .rh .t{font-size:13px;font-weight:700;color:var(--faint);letter-spacing:.04em}
  .ck-revcard .rh .ed{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:600;color:var(--blue);
    background:none;border:0;cursor:pointer}
  .ck-revcard .body{font-size:15px;color:var(--ink);line-height:1.7}
  .ck-revcard .body .mut{color:var(--gray);font-size:14px}

  /* success */
  .ck-success{max-width:560px;margin:0 auto;text-align:center;padding:60px 32px 80px}
  .ck-tick{width:84px;height:84px;border-radius:50%;background:var(--green);display:flex;align-items:center;
    justify-content:center;margin:0 auto 26px;animation:ckpop .5s cubic-bezier(.2,.8,.3,1.2)}
  @keyframes ckpop{0%{transform:scale(.4);opacity:0}100%{transform:scale(1);opacity:1}}
  .ck-success h2{font-size:30px;font-weight:800;letter-spacing:-.02em}
  .ck-success .sub{direction:rtl;color:var(--gray);font-size:16px;margin-top:10px}
  .ck-ordno{display:inline-flex;align-items:center;gap:8px;margin-top:22px;background:var(--stage);
    border-radius:12px;padding:12px 18px;font-size:14px;direction:rtl}
  .ck-ordno b{font-weight:800;direction:ltr}

  /* summary */
  .ck-sum{position:sticky;top:24px;border:1px solid var(--line);border-radius:20px;overflow:hidden}
  .ck-sum-hd{padding:18px 20px;border-bottom:1px solid var(--line);direction:rtl;font-weight:800;font-size:16px}
  .ck-line{display:flex;gap:14px;padding:18px 20px;direction:rtl;align-items:center}
  .ck-line .thumb{width:62px;height:62px;border-radius:13px;background:var(--shot);border:1px solid var(--line);
    display:flex;align-items:center;justify-content:center;overflow:hidden;flex:0 0 auto}
  .ck-line .thumb img{width:74%;height:auto}
  .ck-line .meta{flex:1;min-width:0}
  .ck-line .meta .nm{font-weight:600;font-size:15px}
  .ck-line .meta .op{font-size:13px;color:var(--gray);margin-top:2px}
  .ck-line .meta .qt{font-size:13px;color:var(--gray);margin-top:4px}
  .ck-line .pr{font-weight:700;font-size:15px;direction:ltr}
  .ck-promo{display:flex;gap:8px;padding:0 20px 16px}
  .ck-promo input{flex:1;height:44px;border:1px solid var(--line);border-radius:11px;padding:0 14px;direction:rtl}
  .ck-promo button{height:44px;padding:0 16px;border-radius:11px;border:1px solid var(--ink);background:#fff;
    font-weight:600;font-size:14px;cursor:pointer}
  .ck-promo button:hover{background:var(--stage)}
  .ck-tot{padding:16px 20px;border-top:1px solid var(--line);direction:rtl;display:flex;flex-direction:column;gap:11px}
  .ck-tot .r{display:flex;justify-content:space-between;font-size:14.5px;color:var(--gray)}
  .ck-tot .r .v{color:var(--ink);font-weight:600;direction:ltr}
  .ck-tot .r.free .v{color:var(--green)}
  .ck-tot .grand{display:flex;justify-content:space-between;align-items:baseline;padding-top:13px;
    border-top:1px solid var(--line);margin-top:3px}
  .ck-tot .grand .k{font-size:16px;font-weight:800}
  .ck-tot .grand .v{font-size:24px;font-weight:800;direction:ltr}
  .ck-tot .morow{direction:rtl;font-size:12.5px;color:var(--gray);background:var(--stage);border-radius:10px;
    padding:9px 12px;text-align:center}
  .ck-tot .morow b{color:var(--ink);font-weight:700}
  .ck-trust{display:flex;align-items:center;justify-content:center;gap:8px;padding:14px 20px;
    border-top:1px solid var(--line);font-size:12.5px;color:var(--faint)}

  @container (max-width:900px){
    .ck-main{grid-template-columns:1fr;gap:26px;padding:24px 20px 56px}
    .ck-sum{position:static;order:-1}
    .ck-step .lab{display:none}
    .ck-bar{width:36px;margin:0 8px}
    .ck-top{padding:0 20px}
  }
  @container (max-width:560px){
    .ck-form{grid-template-columns:1fr}
    .ck-plans{grid-template-columns:1fr 1fr}
    .ck-steps{padding:22px 16px 4px}
    .ck-h2{font-size:21px}
    .ck-nav{flex-direction:column-reverse}
    .ck-btn.ghost{width:100%}
  }`;

  const STEPS = ['الشحن', 'الدفع', 'التأكيد'];
  const GOVS = ['القاهرة', 'الجيزة', 'الإسكندرية', 'الدقهلية', 'الشرقية', 'القليوبية', 'أسيوط', 'المنيا', 'أخرى'];

  function CheckoutFlow() {
    const { PRODUCT, fmt, Icon } = window;
    window.injectOnce('ckt-css', css);

    const [step, setStep] = React.useState(0);
    const [method, setMethod] = React.useState('wallet');
    const [plan, setPlan] = React.useState(12);
    const [prov, setProv] = React.useState('valu');
    const [promo, setPromo] = React.useState('');
    const [ship, setShip] = React.useState({ name:'', phone:'', gov:'القاهرة', city:'', addr:'', notes:'' });

    // order: 1× MagSafe bundle to make numbers interesting
    const item = PRODUCT.options.find(o => o.id === 'magsafe');
    const unit = PRODUCT.base + item.delta;     // 2999
    const qty = 1;
    const subtotal = unit * qty;
    const shippingFee = method === 'cod' ? 60 : 0;
    const codFee = method === 'cod' ? 25 : 0;
    const total = subtotal + shippingFee + codFee;
    const monthly = Math.round(total / plan);

    const set = (k, v) => setShip(s => ({ ...s, [k]: v }));
    const go = (n) => { setStep(n); };

    const METHODS = [
      { id:'wallet', icon:'wallet', t:'محفظة رقمية', d:'فودافون كاش · أورنج · اتصالات', badge:'الأشهر' },
      { id:'instapay', icon:'instapay', t:'InstaPay', d:'تحويل فوري من حسابك البنكي' },
      { id:'install', icon:'card', t:'تقسيط', d:'فالو · أمان · بنوك — حتى 24 شهر' },
      { id:'cod', icon:'cash', t:'الدفع عند الاستلام', d:'كاش للمندوب (+ 25 ج رسوم خدمة)' },
    ];
    const methodLabel = {
      wallet: 'محفظة رقمية', instapay: 'InstaPay',
      install: `تقسيط ${plan} شهر · ${({valu:'فالو',aman:'أمان',bank:'بنك'})[prov]}`,
      cod: 'الدفع عند الاستلام',
    }[method];

    /* ---------- SUCCESS ---------- */
    if (step === 3) {
      return (
        <div className="ckt">
          <TopBar Icon={Icon} />
          <div className="ck-success">
            <div className="ck-tick"><Icon name="check" size={44} color="#fff" stroke={2.4}/></div>
            <h2>تم تأكيد طلبك 🎉</h2>
            <p className="sub">هنبعتلك رسالة تأكيد على {ship.phone || 'رقمك'}، وهتستلم خلال 2–3 أيام عمل.</p>
            <div className="ck-ordno"><Icon name="tag" size={18}/><span>رقم الطلب</span><b>#TIP-{Math.floor(100000+Math.random()*900000)}</b></div>
            <div className="ck-nav" style={{ maxWidth:420, margin:'30px auto 0' }}>
              <button className="ck-btn primary" onClick={() => go(0)}>متابعة التسوق</button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="ckt">
        <TopBar Icon={Icon} />

        {/* stepper */}
        <div className="ck-steps">
          {STEPS.map((s, i) => (
            <React.Fragment key={s}>
              {i > 0 && <div className={'ck-bar'+(step>=i?' fill':'')}><i/></div>}
              <div className={'ck-step'+(step===i?' active':'')+(step>i?' done':'')}>
                <span className="num">{step>i ? <Icon name="check" size={15} color="#fff" stroke={2.6}/> : i+1}</span>
                <span className="lab">{s}</span>
              </div>
            </React.Fragment>
          ))}
        </div>

        <div className="ck-main">
          <div className="ck-pane">
            {step === 0 && <ShippingStep ship={ship} set={set} go={go} />}
            {step === 1 && (
              <PaymentStep
                Icon={Icon} fmt={fmt} METHODS={METHODS} method={method} setMethod={setMethod}
                plan={plan} setPlan={setPlan} prov={prov} setProv={setProv} total={total} go={go}
              />
            )}
            {step === 2 && (
              <ConfirmStep
                Icon={Icon} ship={ship} methodLabel={methodLabel} go={go} setStep={setStep}
              />
            )}
          </div>

          <OrderSummary
            Icon={Icon} fmt={fmt} unit={unit} qty={qty} subtotal={subtotal}
            shippingFee={shippingFee} codFee={codFee} total={total} monthly={monthly}
            plan={plan} method={method} promo={promo} setPromo={setPromo}
          />
        </div>
      </div>
    );
  }

  /* ---------- sub-components ---------- */
  function TopBar({ Icon }) {
    return (
      <header className="ck-top">
        <div className="ck-brand"><span className="mk">T</span>Trade In Plus</div>
        <div className="ck-secure"><Icon name="lock" size={16}/> دفع آمن ومشفّر</div>
      </header>
    );
  }

  function ShippingStep({ ship, set, go }) {
    const { Icon } = window;
    const ok = ship.name.trim() && ship.phone.trim().length >= 8 && ship.addr.trim();
    return (
      <>
        <h2 className="ck-h2">بيانات الشحن</h2>
        <p className="ck-hint">هنوصّلك الطلب على العنوان ده.</p>
        <div className="ck-form">
          <div className="ck-field full">
            <label>الاسم بالكامل <span className="req">*</span></label>
            <input className="ck-input" placeholder="مثال: أحمد محمد" value={ship.name} onChange={e=>set('name',e.target.value)} />
          </div>
          <div className="ck-field">
            <label>رقم الموبايل <span className="req">*</span></label>
            <input className="ck-input" placeholder="01x xxxx xxxx" inputMode="tel" value={ship.phone} onChange={e=>set('phone',e.target.value)} />
          </div>
          <div className="ck-field">
            <label>المحافظة</label>
            <select className="ck-input" value={ship.gov} onChange={e=>set('gov',e.target.value)}>
              {GOVS.map(g => <option key={g}>{g}</option>)}
            </select>
          </div>
          <div className="ck-field">
            <label>المدينة / الحي</label>
            <input className="ck-input" placeholder="مثال: المعادي" value={ship.city} onChange={e=>set('city',e.target.value)} />
          </div>
          <div className="ck-field">
            <label>أقرب علامة مميزة</label>
            <input className="ck-input" placeholder="اختياري" value={ship.landmark||''} onChange={e=>set('landmark',e.target.value)} />
          </div>
          <div className="ck-field full">
            <label>العنوان بالتفصيل <span className="req">*</span></label>
            <textarea className="ck-input" placeholder="اسم الشارع، رقم العمارة، الدور، الشقة" value={ship.addr} onChange={e=>set('addr',e.target.value)} />
          </div>
        </div>
        <div className="ck-nav">
          <button className="ck-btn primary" disabled={!ok} style={{ opacity: ok?1:.45, pointerEvents: ok?'auto':'none' }} onClick={()=>go(1)}>
            متابعة للدفع <Icon name="back" size={20} color="#fff"/>
          </button>
        </div>
      </>
    );
  }

  function PaymentStep({ Icon, fmt, METHODS, method, setMethod, plan, setPlan, prov, setProv, total, go }) {
    const plans = [6, 12, 24];
    const provs = [{id:'valu',n:'فالو'},{id:'aman',n:'أمان'},{id:'bank',n:'بنوك'}];
    return (
      <>
        <h2 className="ck-h2">طريقة الدفع</h2>
        <p className="ck-hint">اختار الطريقة اللي تناسبك.</p>
        <div className="ck-pays">
          {METHODS.map(m => (
            <div key={m.id} className={'ck-pay'+(method===m.id?' on':'')}>
              <div className="ck-pay-hd" onClick={()=>setMethod(m.id)}>
                <span className="ck-radio"/>
                <span className="ck-pay-ic"><Icon name={m.icon} size={22}/></span>
                <span className="ck-pay-tx"><span className="t">{m.t}</span><span className="d">{m.d}</span></span>
                {m.badge && <span className="ck-pay-badge">{m.badge}</span>}
              </div>
              <div className="ck-pay-body">
                <div className="ck-pay-inner">
                  {m.id==='wallet' && (
                    <div className="ck-walletfields">
                      <input className="ck-input" placeholder="رقم المحفظة (01x xxxx xxxx)" inputMode="tel"/>
                      <div className="ck-note"><span className="ic"><Icon name="phone" size={18}/></span>
                        هيوصلك طلب دفع على تطبيق المحفظة، أكّده خلال 5 دقائق.</div>
                    </div>
                  )}
                  {m.id==='instapay' && (
                    <div className="ck-note"><span className="ic"><Icon name="instapay" size={18}/></span>
                      هنحوّلك لتطبيق InstaPay لإتمام التحويل الفوري بأمان، وترجع تلقائيًا بعد الدفع.</div>
                  )}
                  {m.id==='install' && (
                    <>
                      <div className="ck-plans">
                        {plans.map(p => (
                          <button key={p} className={'ck-plan'+(plan===p?' on':'')} onClick={()=>setPlan(p)}>
                            <div className="mo">{p} <span>شهر</span></div>
                            <div className="per">EGP {fmt(Math.round(total/p))}/شهر</div>
                          </button>
                        ))}
                      </div>
                      <div className="ck-provs">
                        {provs.map(pv => (
                          <button key={pv.id} className={'ck-prov'+(prov===pv.id?' on':'')} onClick={()=>setProv(pv.id)}>{pv.n}</button>
                        ))}
                      </div>
                    </>
                  )}
                  {m.id==='cod' && (
                    <div className="ck-note"><span className="ic"><Icon name="cash" size={18}/></span>
                      تدفع كاش للمندوب عند الاستلام. تُضاف رسوم خدمة 25 ج وشحن 60 ج على الطلب.</div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="ck-nav">
          <button className="ck-btn ghost" onClick={()=>go(0)}><Icon name="chevron" size={18}/> رجوع</button>
          <button className="ck-btn primary" onClick={()=>go(2)}>مراجعة الطلب <Icon name="back" size={20} color="#fff"/></button>
        </div>
      </>
    );
  }

  function ConfirmStep({ Icon, ship, methodLabel, go, setStep }) {
    const [placing, setPlacing] = React.useState(false);
    const place = () => { setPlacing(true); setTimeout(()=>{ setPlacing(false); setStep(3); }, 1100); };
    return (
      <>
        <h2 className="ck-h2">مراجعة وتأكيد</h2>
        <p className="ck-hint">اتأكد إن كل حاجة مظبوطة قبل ما تأكد الطلب.</p>
        <div className="ck-rev">
          <div className="ck-revcard">
            <div className="rh"><span className="t">الشحن إلى</span><button className="ed" onClick={()=>go(0)}><Icon name="edit" size={15}/> تعديل</button></div>
            <div className="body">
              <div>{ship.name || '—'}</div>
              <div className="mut">{ship.phone || '—'}</div>
              <div className="mut">{[ship.addr, ship.city, ship.gov].filter(Boolean).join('، ') || '—'}</div>
            </div>
          </div>
          <div className="ck-revcard">
            <div className="rh"><span className="t">طريقة الدفع</span><button className="ed" onClick={()=>go(1)}><Icon name="edit" size={15}/> تعديل</button></div>
            <div className="body">{methodLabel}</div>
          </div>
        </div>
        <div className="ck-nav">
          <button className="ck-btn ghost" onClick={()=>go(1)}><Icon name="chevron" size={18}/> رجوع</button>
          <button className="ck-btn primary" onClick={place} style={{ opacity: placing?.7:1, pointerEvents: placing?'none':'auto' }}>
            {placing ? 'جارٍ تأكيد الطلب…' : <><Icon name="lock" size={19} color="#fff"/> تأكيد الطلب والدفع</>}
          </button>
        </div>
      </>
    );
  }

  function OrderSummary({ Icon, fmt, unit, qty, subtotal, shippingFee, codFee, total, monthly, plan, method, promo, setPromo }) {
    return (
      <aside className="ck-sum">
        <div className="ck-sum-hd">ملخص الطلب</div>
        <div className="ck-line">
          <div className="thumb"><img src="assets/charger.png" alt=""/></div>
          <div className="meta">
            <div className="nm">MagSafe Bundle</div>
            <div className="op">محول 20W + شاحن MagSafe · أبيض</div>
            <div className="qt">الكمية: {qty}</div>
          </div>
          <div className="pr">EGP {fmt(unit)}</div>
        </div>
        <div className="ck-promo">
          <input placeholder="كود الخصم" value={promo} onChange={e=>setPromo(e.target.value)} />
          <button>تطبيق</button>
        </div>
        <div className="ck-tot">
          <div className="r"><span>الإجمالي الفرعي</span><span className="v">EGP {fmt(subtotal)}</span></div>
          <div className={'r'+(shippingFee?'':' free')}><span>الشحن</span><span className="v">{shippingFee?`EGP ${fmt(shippingFee)}`:'مجاني'}</span></div>
          {codFee>0 && <div className="r"><span>رسوم الدفع عند الاستلام</span><span className="v">EGP {fmt(codFee)}</span></div>}
          <div className="grand"><span className="k">الإجمالي</span><span className="v">EGP {fmt(total)}</span></div>
          {method==='install' && (
            <div className="morow">أو <b>EGP {fmt(monthly)}</b> شهريًا على <b>{plan}</b> شهر</div>
          )}
        </div>
        <div className="ck-trust"><Icon name="shield" size={15}/> مشترياتك مضمونة وأصلية بضمان Apple</div>
      </aside>
    );
  }

  window.CheckoutFlow = CheckoutFlow;
})();
