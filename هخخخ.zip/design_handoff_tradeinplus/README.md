# Handoff: Trade In Plus — Product Page & Checkout Gateway

## Overview
This package contains two designs for the **Trade In Plus** e-commerce experience (an Apple-style accessories store, Arabic/English mixed, RTL-aware):

1. **Product Detail Page (PDP)** — a redesign of the "Chargers & Cables" product page, delivered in **two directions** to choose between.
2. **Checkout Gateway** — a 3-step checkout flow (Shipping → Payment → Confirm) with a sticky order summary, in a single refined version.

Both share one visual identity: minimal, white, Apple-inspired, with mixed Arabic/English copy and RTL text alignment for Arabic content.

## About the Design Files
The files in this bundle are **design references created in HTML** — interactive prototypes showing the intended look and behavior. **They are not production code to copy directly.** The task is to **recreate these designs in the target codebase's existing environment** (React, Vue, Next.js, etc.) using its established components, styling system, and conventions. If no frontend environment exists yet, pick the most appropriate framework for the project and implement there.

The prototypes are built with React (UMD + Babel standalone, single-file). Treat the JSX as a reference for structure, state, and styling values — re-implement idiomatically.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, radii, and interactions are all specified. Recreate the UI pixel-perfectly using the codebase's existing libraries and patterns. Exact tokens are listed in **Design Tokens** below.

---

## Screens / Views

### 1. PDP — Direction A: "Clean Classic"
A refined evolution of the original product page.

- **Purpose**: Let the user view the charger, pick a color and option (which updates price), set quantity, and add to cart / buy now.
- **Layout**: Two-column grid `grid-template-columns: 1.05fr 1fr; gap: 64px; max-width: 1240px`. Left = sticky media (`position: sticky; top: 24px`), right = info column. Below the hero is a full-width features band on `--stage` background with a 4-column card grid.
- **Components**:
  - **Top nav** (64px tall, bottom border `--line`): left icon row (dark/account/bag/search, 20px stroke icons, gap 22px); center text links (About / Stores / Business / Services / Shop, 14px, `--gray`); right brand lockup "Trade In Plus" (800 weight, 20px) with a 30×30 dark rounded-square "T" mark. Bag icon shows a blue count badge when items added.
  - **Breadcrumb**: RTL, right-aligned, 13px `--gray`, current page in `--ink` 600.
  - **Media stage**: square (`aspect-ratio: 1/1`), background `--shot` (#fdfdfd), `border-radius: 24px`. Product image at 72% width with `drop-shadow(0 30px 40px rgba(0,0,0,.10))`. Hovering the relevant thumb applies a CSS transform to zoom into image detail (the gallery reuses one photo with different `transform: scale()/translate()` crops). 4 thumbnails below (gap 12px), selected has `--ink` outline.
  - **Title block**: eyebrow "ACCESSORIES" (12px, letter-spacing .32em, `--gray`), H1 "Chargers & Cables" (52px, 800, letter-spacing -.03em, line-height 1.02), Arabic subtitle (RTL, 18px, `--gray`), rating row (5 stars #f5a623, "4.9 · 1,247 تقييم").
  - **Price card**: bordered (`--line`, radius 18px, padding 22×24). "EGP" 18px `--gray` + value 40px 800. Divider, then installment line "أو EGP {monthly} شهريًا لمدة 24 شهر بدون فوائد".
  - **Color swatches**: 30px circles, selected has `--ink` outline ring (outline-offset 2px).
  - **Option cards**: flex row, each card border `--line` radius 14px; selected = `--ink` border + `0 0 0 1px --ink` ring. Shows option name (15px 600), Arabic note (12px `--gray`), and "+{delta} EGP" in `--blue` when there's an upcharge.
  - **Buy row**: quantity stepper (54px tall, bordered, − / n / +) beside the primary "أضف إلى السلة" button (flex:1). Below: full-width ghost "اشترِ الآن".
  - **Trust list**: 4 rows, RTL, each with a 38px rounded-square `--stage` icon tile + 15px label (fast delivery / Apple warranty / 0% installments / instant trade-in).
  - **Features band**: 4 white cards (radius 18px, padding 26×22), each a 44px icon tile + English title (16px 600) + Arabic description (13px `--gray`).

### 2. PDP — Direction B: "Premium Editorial"
A more dramatic, editorial layout.

- **Purpose**: Same shopping task, presented with a large product stage and a focused purchase panel.
- **Layout**: Full-bleed two-column hero `grid-template-columns: 1.25fr 1fr; min-height: 760px`. Left = large product stage; right = purchase panel (padding 64×56). Below: a centered feature strip (top/bottom borders), then a 2-column specs list (`max-width: 1100px`).
- **Components**:
  - **Top bar** (60px): brand lockup, center nav, right icons (search/account/bag). Bag badge is `--ink` (not blue) here.
  - **Product stage**: `--shot` background, fills its column. A giant watermark word sits behind the product (`font-size: clamp(120px, 22cqw, 340px)`, color `rgba(0,0,0,.035)`, 800 weight) that changes with the selected option: "20W" / "1m" / "MagSafe". Product image at 52% width (max 440px) with `drop-shadow(0 50px 60px rgba(0,0,0,.16))`; on hover it lifts (`translateY(-10px) scale(1.03)`). Eyebrow tag top-left, color dots column left-center.
  - **Purchase panel**: eyebrow, H1 "Chargers & Cables" (46px 800), Arabic sub, rating. Price row + a pill-shaped installment chip (`--stage` bg, radius 999px). 
  - **Segmented option control**: `--stage` track, radius 14px, padding 4px; each segment shows option name + delta ("+100" / "الأساسي") stacked; selected segment = white bg + shadow, delta turns `--blue`.
  - **Color pills**: rounded-999px bordered chips with a 16px swatch; selected = `--ink` border + ring.
  - **Actions**: ghost "اشترِ الآن" + primary "أضف إلى السلة" side by side (each flex:1, 56px tall, radius 15px).
  - **2×2 feature grid**: bordered container radius 16px, internal dividers, RTL rows with icon + label.
  - **Feature strip**: centered inline list, each item prefixed by a 5px `--blue` dot.
  - **Specs**: 2-column rows, key in `--gray`, value 600 (value is LTR).

> **Recommendation**: pick ONE direction to ship. Direction A is closer to the original/conventional PDP; Direction B is more brand-forward.

### 3. Checkout Gateway (single version)
3-step flow with a persistent order summary.

- **Purpose**: Collect shipping info, choose a payment method, review, and place the order.
- **Layout**: Top bar (60px) → centered **stepper** → two-column body `grid-template-columns: 1fr 400px; gap: 40px; max-width: 1140px`. Left = active step pane, right = sticky order summary (`position: sticky; top: 24px`). On mobile (<900px) it collapses to one column and the summary moves to the top (`order: -1`).
- **Stepper**: 3 steps (الشحن / الدفع / التأكيد). Each = a 30px circular number badge + label. States: upcoming (`--line` border, `--faint` text), active (`--ink` filled), done (`--green` filled with check icon). Connector bars (64px) fill green left-to-right (`transform: scaleX`) as steps complete.
- **Step 1 — Shipping**: 2-column form (`gap: 16px`), RTL fields. Fields: full name*, mobile*, governorate (select), city/area, nearest landmark (optional), full address* (textarea, full-width). Inputs 50px tall, radius 13px, focus = `--ink` border + `0 0 0 3px rgba(0,0,0,.06)` ring. Required-field validation: the "متابعة للدفع" button is disabled (opacity .45) until name + phone (≥8 chars) + address are filled.
- **Step 2 — Payment**: vertical list of accordion method cards. Selected card = `--ink` border + ring, radio fills `--ink`, and its body expands (`max-height` transition). Methods:
  - **محفظة رقمية** (digital wallet — Vodafone/Orange/Etisalat), badge "الأشهر". Body: wallet-number input + info note.
  - **InstaPay**. Body: info note about redirect.
  - **تقسيط** (installments). Body: 3 plan tiles (6 / 12 / 24 months) showing per-month price computed live (`total / months`); selected tile = `--ink` border. Below: provider chips فالو / أمان / بنوك (selected = `--ink` filled).
  - **الدفع عند الاستلام** (COD). Adds EGP 60 shipping + EGP 25 service fee to the summary. Body: info note.
- **Step 3 — Confirm**: two review cards (shipping address, payment method) each with an "تعديل" (edit) link that jumps back to the relevant step. Primary button "تأكيد الطلب والدفع" shows a "جارٍ تأكيد الطلب…" loading label for ~1.1s, then advances to success.
- **Success screen**: centered. 84px green circle with white check (pop animation `cubic-bezier(.2,.8,.3,1.2)`), H2 "تم تأكيد طلبك 🎉", Arabic subtext referencing the entered phone, an order-number chip "#TIP-XXXXXX" (random 6 digits), and a "متابعة التسوق" button that resets to step 0.
- **Order summary (sidebar)**: header "ملخص الطلب", product line (62px thumb + name "MagSafe Bundle" + option text + qty + price), promo-code input + "تطبيق" button, totals block (subtotal, shipping [shows "مجاني" in green when free], COD fee row when applicable, grand total 24px 800), an installment hint row when the install method is active, and a trust footer "مشترياتك مضمونة وأصلية بضمان Apple".

---

## Interactions & Behavior
- **PDP option/color selection** updates the displayed price and monthly installment instantly (no reload).
- **PDP gallery thumbnails** swap the stage image's CSS `transform` to show different crops of one photo.
- **Add to cart**: bag badge increments; button briefly switches to a green "تمت الإضافة" + check state for ~1.6s, then reverts.
- **Checkout stepper** is linear forward with edit-links that jump backward. Forward nav from Shipping is gated on validation.
- **Payment accordion**: only one method expanded at a time (the selected one).
- **Installment math**: `monthly = round(total / months)`, recomputed when plan or method changes.
- **Place order**: 1.1s simulated processing → success screen.
- **Responsive**: all three designs use **CSS container queries** (`container-type: inline-size`) with breakpoints at **900px** (collapse to single column) and **560px** (stack forms, segmented controls shrink, nav buttons stack). Re-implement with container queries if supported, otherwise standard media queries against viewport.
- **Animations**: success tick pop (0.5s), accordion `max-height` (0.3s ease), stepper bar fill (0.35s), button press `scale(.985)` (0.12s), image hover lift (0.55–0.6s `cubic-bezier(.2,.7,.2,1)`).

## State Management
PDP (per page):
- `option` (selected SKU: usbc20 | cable1m | magsafe), `color`, `qty`, `activeThumb`, `bagCount`, `added` (transient flag).

Checkout:
- `step` (0–3; 3 = success), `method` (wallet | instapay | install | cod), `installPlan` (6 | 12 | 24), `installProvider` (valu | aman | bank), `promo` (string), `shipping` ({ name, phone, gov, city, addr, landmark, notes }).
- Derived: `subtotal`, `shippingFee`, `codFee`, `total`, `monthly`, `methodLabel`.
- No real data fetching in the prototype — wire price/SKU/order endpoints in the real app. Replace the simulated 1.1s place-order timeout with the real payment API call, and the random order number with the server-issued one.

## Design Tokens
**Colors**
- `--ink` (primary text / dark): `#1d1d1f`
- `--gray` (secondary text): `#6e6e73` (PDP A) / `#86868b` (PDP B & checkout `--faint`)
- `--line` (borders): `#e5e5e8` (A / checkout) / `#e9e9ec` (B)
- `--stage` (tinted surface): `#f5f5f7` (A) / `#f3f3f5` (B)
- `--shot` (product backdrop): `#fdfdfd`
- `--blue` (accent / links / deltas): `#0071e3`
- `--green` (success / done): `#1a8a4a`
- Star color: `#f5a623`
- Required asterisk: `#d8412f`
- Page background (canvas): `#fff`

**Typography**
- Family: `-apple-system, BlinkMacSystemFont, "SF Pro Text"/"SF Pro Display", "Helvetica Neue", Arial, sans-serif`. Display sizes use SF Pro Display.
- H1 PDP A: 52px / 800 / -.03em / 1.02 (40px ≤900px, 34px ≤560px)
- H1 PDP B: 46px / 800 / -.03em (40px ≤980px, 32px ≤560px)
- Price value: 40px (A) / 44px (B) / 800
- Section H2 (checkout): 24px / 800 / -.02em (21px ≤560px)
- Eyebrow: 12px / 600 / letter-spacing .28–.32em
- Body: 14–18px / 1.5
- Grand total: 24px / 800

**Spacing / radii / shadows**
- Section max-width: 1240px (PDP A), 1100px (PDP B specs/strip), 1140px (checkout)
- Radii: inputs 13px, option cards 14px, price/pills 14–18px, stage 24px, summary 20px, icon tiles 10–12px, pill/chip 999px
- Inputs/steppers height: 50–54px; primary buttons 54–56px
- Shadows: product (A) `0 30px 40px rgba(0,0,0,.10)`; product (B) `0 50px 60px rgba(0,0,0,.16)`; focus ring `0 0 0 3px rgba(0,0,0,.06)`; selected ring `0 0 0 1px var(--ink)`
- Breakpoints (container queries): 900px, 560px (PDP B also 980px)

## Assets
- `assets/charger.png` — the product photo, **cropped from the user's original screenshot** of the live site. The PDP gallery reuses this single image with different CSS transforms for "detail" views. The checkout summary thumb uses the same file. Replace with proper product photography (ideally background-removed PNGs) in production; a transparent-background cutout would render even cleaner on the tinted stages.
- All icons are inline SVG (stroke-based, 24×24 viewBox) defined in `pdp-shared.jsx` (`ICON_PATHS`). Swap for the codebase's existing icon set — names map to: truck, shield, card, trade(refresh), check, minus, plus, cart, bag, user, search, moon, chevron, back, bolt, wallet, phone, bank, cash, lock, edit, pin, tag, instapay.

## Files
Reference files included in this bundle:
- `Product Page Redesign.html` — entry point; mounts both PDP directions in a comparison canvas (Desktop + Mobile artboards).
- `variation-a.jsx` — PDP Direction A ("Clean Classic").
- `variation-b.jsx` — PDP Direction B ("Premium Editorial").
- `Checkout Gateway.html` — entry point; mounts the checkout flow (Desktop + Mobile artboards).
- `checkout.jsx` — the full 3-step checkout flow + order summary.
- `pdp-shared.jsx` — shared product data (`PRODUCT`), price helpers (`priceFor`, `monthlyFor`, `fmt`), `Stars`, and the `Icon` set. **Read this first** — it's the source of truth for product data and tokens.
- `assets/charger.png` — product image.
- `design-canvas.jsx` — presentation harness only (pan/zoom canvas for viewing the artboards). **Not part of the product** — ignore when implementing.

> Note: the `.html` files load React/ReactDOM/Babel from a CDN and use Babel-in-the-browser purely so the prototype runs standalone. Do not replicate that setup in production — use the codebase's real build pipeline.
