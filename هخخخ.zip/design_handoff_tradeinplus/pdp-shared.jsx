/* pdp-shared.jsx — shared data, helpers, and icons for the PDP redesigns.
   Exports everything to window so the variation files (separate babel scopes)
   can use them. */

const PRODUCT = {
  brand: 'Trade In Plus',
  eyebrow: 'ACCESSORIES',
  title: 'Chargers & Cables',
  subtitle: 'شحن سريع وكابلات أصلية بمعايير Apple.',
  rating: 4.9,
  reviews: 1247,
  base: 1799,           // base = USB-C 20W
  months: 24,
  colors: [
    { id: 'white', name: 'White', nameAr: 'أبيض', hex: '#f5f5f7', ring: '#d2d2d7' },
  ],
  options: [
    { id: 'usbc20',  name: 'USB-C 20W',     note: 'الأساسي',      delta: 0,    desc: 'محول طاقة USB-C بقدرة 20 واط' },
    { id: 'cable1m', name: 'USB-C Cable 1m', note: '+ كابل',       delta: 100,  desc: 'محول 20W + كابل USB-C بطول متر' },
    { id: 'magsafe', name: 'MagSafe',        note: 'شحن مغناطيسي', delta: 1200, desc: 'محول 20W + شاحن MagSafe لاسلكي' },
  ],
  features: [
    { icon: 'truck',  ar: 'توصيل سريع داخل مصر',        en: 'Fast delivery' },
    { icon: 'shield', ar: 'أصلية بضمان Apple',           en: 'Apple warranty' },
    { icon: 'card',   ar: 'تقسيط حتى 24 شهر بدون فوائد', en: '0% installments' },
    { icon: 'trade',  ar: 'Trade-In فوري لجهازك القديم', en: 'Instant trade-in' },
  ],
  specs: [
    { k: 'القدرة', v: '20W USB-C' },
    { k: 'التوافق', v: 'iPhone · iPad · AirPods' },
    { k: 'الشحن السريع', v: '0–50% خلال 30 دقيقة' },
    { k: 'الضمان', v: 'سنة كاملة' },
  ],
};

const fmt = (n) => n.toLocaleString('en-US');
const priceFor = (optId) => PRODUCT.base + (PRODUCT.options.find(o => o.id === optId)?.delta || 0);
const monthlyFor = (optId) => Math.round(priceFor(optId) / PRODUCT.months);

function Stars({ value = 5, size = 15, color = '#f5a623' }) {
  return (
    <span style={{ display: 'inline-flex', gap: 1, verticalAlign: 'middle' }} aria-label={`${value} stars`}>
      {[0,1,2,3,4].map(i => (
        <svg key={i} width={size} height={size} viewBox="0 0 20 20" fill={color}>
          <path d="M10 1.6l2.47 5.01 5.53.8-4 3.9.94 5.5L10 14.2l-4.95 2.6.95-5.5-4-3.9 5.53-.8z"/>
        </svg>
      ))}
    </span>
  );
}

const ICON_PATHS = {
  truck:  '<path d="M3 6.5h10v8H3z"/><path d="M13 9h4l3 3v2.5h-7z"/><circle cx="7" cy="17" r="1.8"/><circle cx="17.5" cy="17" r="1.8"/>',
  shield: '<path d="M12 3l7 3v5c0 4.4-3 7.7-7 9-4-1.3-7-4.6-7-9V6z"/><path d="M9 11.5l2 2 4-4.2"/>',
  card:   '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18"/><path d="M7 14.5h4"/>',
  trade:  '<path d="M4 8a8 8 0 0 1 13-2.5L20 8"/><path d="M20 4v4h-4"/><path d="M20 16a8 8 0 0 1-13 2.5L4 16"/><path d="M4 20v-4h4"/>',
  check:  '<path d="M5 12.5l4.2 4.3L19 7"/>',
  minus:  '<path d="M5 12h14"/>',
  plus:   '<path d="M12 5v14M5 12h14"/>',
  cart:   '<circle cx="9" cy="20" r="1.4"/><circle cx="17.5" cy="20" r="1.4"/><path d="M3 4h2l2.2 11h10.3l1.8-8H6"/>',
  bag:    '<path d="M6 8h12l-1 12H7z"/><path d="M9 8a3 3 0 0 1 6 0"/>',
  user:   '<circle cx="12" cy="8" r="3.4"/><path d="M5.5 20a6.5 6.5 0 0 1 13 0"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4-4"/>',
  moon:   '<path d="M20 14.5A8 8 0 0 1 9.5 4 7 7 0 1 0 20 14.5z"/>',
  chevron:'<path d="M9 5l7 7-7 7"/>',
  back:   '<path d="M15 5l-7 7 7 7"/>',
  bolt:   '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  wallet: '<rect x="3" y="6" width="18" height="13" rx="2.5"/><path d="M16 12.5h2"/><path d="M3 9h13a2 2 0 0 1 0 4H3"/>',
  phone:  '<rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M10.5 18.5h3"/>',
  bank:   '<path d="M3 9.5l9-6 9 6"/><path d="M5 9.5V19M19 9.5V19M9.5 9.5V19M14.5 9.5V19"/><path d="M3 19h18"/>',
  cash:   '<rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 9.5v5M18 9.5v5"/>',
  lock:   '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  edit:   '<path d="M4 20h4l10-10-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  pin:    '<path d="M12 21s7-5.5 7-11a7 7 0 0 0-14 0c0 5.5 7 11 7 11z"/><circle cx="12" cy="10" r="2.6"/>',
  tag:    '<path d="M3 12V4h8l9 9-7 7z"/><circle cx="7.5" cy="7.5" r="1.4"/>',
  instapay:'<path d="M5 12h14"/><path d="M13 6l6 6-6 6"/><path d="M5 7v10"/>',
};

function Icon({ name, size = 20, stroke = 1.6, color = 'currentColor', fill = 'none' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={color}
      strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
      dangerouslySetInnerHTML={{ __html: ICON_PATHS[name] || '' }} />
  );
}

function injectOnce(id, css) {
  if (document.getElementById(id)) return;
  const s = document.createElement('style');
  s.id = id; s.textContent = css;
  document.head.appendChild(s);
}

Object.assign(window, { PRODUCT, fmt, priceFor, monthlyFor, Stars, Icon, injectOnce });
