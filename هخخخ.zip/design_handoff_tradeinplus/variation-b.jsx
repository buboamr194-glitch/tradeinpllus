/* variation-b.jsx — "Premium Editorial" PDP.
   Big tinted product stage + floating purchase card, segmented option control,
   oversize watermark. Responsive via container queries. Exports window.VariationB */

(function () {
  const css = `
  .pdpB{container-type:inline-size;background:#fff;color:#1d1d1f;
    font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Arial,sans-serif;
    -webkit-font-smoothing:antialiased;line-height:1.5;
    --ink:#1d1d1f;--gray:#86868b;--line:#e9e9ec;--stage:#f3f3f5;--shot:#fdfdfd;--blue:#0071e3}
  .pdpB *{box-sizing:border-box;margin:0;padding:0}
  .pdpB button{font-family:inherit;cursor:pointer}

  .b-top{display:flex;align-items:center;justify-content:space-between;height:60px;padding:0 36px;
    border-bottom:1px solid var(--line)}
  .b-top .brand{display:flex;align-items:center;gap:9px;font-weight:800;font-size:18px;letter-spacing:-.02em}
  .b-top .brand .mk{width:26px;height:26px;border-radius:7px;background:var(--ink);color:#fff;display:flex;
    align-items:center;justify-content:center;font-size:13px;font-weight:800}
  .b-top .nav{display:flex;gap:26px;font-size:13.5px;color:var(--gray);font-weight:500}
  .b-top .nav span{cursor:pointer}.b-top .nav span:hover{color:var(--ink)}
  .b-top .ic{display:flex;gap:18px;color:var(--ink)}
  .b-top .ic button{border:0;background:none;color:inherit;display:flex;padding:0;position:relative;opacity:.85}
  .b-top .ic .count{position:absolute;top:-6px;right:-8px;background:var(--ink);color:#fff;font-size:10px;
    font-weight:700;min-width:16px;height:16px;border-radius:9px;display:flex;align-items:center;justify-content:center;padding:0 4px}

  .b-hero{display:grid;grid-template-columns:1.25fr 1fr;min-height:760px}
  .b-stage{position:relative;background:var(--shot);overflow:hidden;display:flex;align-items:center;
    justify-content:center}
  .b-water{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
    font-family:-apple-system,"SF Pro Display","Helvetica Neue",Arial,sans-serif;
    font-weight:800;letter-spacing:-.04em;color:rgba(0,0,0,.035);font-size:clamp(120px,22cqw,340px);
    user-select:none;white-space:nowrap}
  .b-shot{position:relative;width:52%;max-width:440px;filter:drop-shadow(0 50px 60px rgba(0,0,0,.16));
    transition:transform .6s cubic-bezier(.2,.7,.2,1)}
  .b-stage:hover .b-shot{transform:translateY(-10px) scale(1.03)}
  .b-dots{position:absolute;left:30px;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;gap:12px;z-index:2}
  .b-dot{width:34px;height:34px;border-radius:50%;border:1px solid var(--line);background:#fff;cursor:pointer;
    box-shadow:0 0 0 2px #fff inset;outline:2px solid transparent;outline-offset:2px;transition:outline-color .15s}
  .b-dot.on{outline-color:var(--ink)}
  .b-tag{position:absolute;top:28px;left:30px;font-size:11px;letter-spacing:.3em;color:var(--gray);font-weight:600}

  .b-panel{padding:64px 56px;display:flex;flex-direction:column;justify-content:center;max-width:600px}
  .b-eye{font-size:11px;letter-spacing:.32em;color:var(--gray);font-weight:600}
  .b-h1{font-size:46px;line-height:1.0;letter-spacing:-.03em;font-weight:800;margin:12px 0 0;
    font-family:-apple-system,"SF Pro Display","Helvetica Neue",Arial,sans-serif}
  .b-sub{direction:rtl;text-align:right;color:var(--gray);font-size:17px;margin-top:14px}
  .b-rate{display:flex;align-items:center;gap:9px;margin-top:14px;direction:rtl;justify-content:flex-start}
  .b-rate .num{font-weight:600;font-size:14px}.b-rate .cnt{color:var(--gray);font-size:14px}

  .b-pricewrap{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;margin-top:30px;
    padding-bottom:22px;border-bottom:1px solid var(--line)}
  .b-price .cur{font-size:15px;color:var(--gray);font-weight:600;margin-right:6px}
  .b-price .val{font-size:44px;font-weight:800;letter-spacing:-.025em}
  .b-mo{background:var(--stage);border-radius:999px;padding:9px 14px;direction:rtl;text-align:center;
    font-size:12.5px;color:var(--gray);line-height:1.35}
  .b-mo b{color:var(--ink);font-weight:700}

  .b-sec{margin-top:24px}
  .b-sec .hd{display:flex;justify-content:space-between;align-items:baseline;font-size:13px;margin-bottom:11px}
  .b-sec .hd .k{color:var(--gray);letter-spacing:.02em}
  .b-sec .hd .v{font-weight:600}
  .b-seg{display:flex;background:var(--stage);border-radius:14px;padding:4px;gap:4px}
  .b-seg button{flex:1;border:0;background:transparent;border-radius:11px;padding:11px 8px;color:var(--gray);
    font-weight:600;font-size:14px;transition:all .18s;display:flex;flex-direction:column;align-items:center;gap:3px}
  .b-seg button .d{font-size:11px;font-weight:600;color:var(--gray)}
  .b-seg button.on{background:#fff;color:var(--ink);box-shadow:0 1px 3px rgba(0,0,0,.12)}
  .b-seg button.on .d{color:var(--blue)}
  .b-pills{display:flex;gap:10px}
  .b-pill{display:flex;align-items:center;gap:8px;border:1px solid var(--line);border-radius:999px;
    padding:8px 14px;background:#fff;font-size:14px;font-weight:500;transition:border-color .15s}
  .b-pill .swt{width:16px;height:16px;border-radius:50%;border:1px solid var(--line)}
  .b-pill.on{border-color:var(--ink);box-shadow:0 0 0 1px var(--ink)}

  .b-actions{display:flex;gap:12px;margin-top:30px}
  .b-cta{flex:1;display:flex;align-items:center;justify-content:center;gap:9px;height:56px;border-radius:15px;
    font-size:16px;font-weight:600;transition:transform .12s,background .15s}
  .b-cta:active{transform:scale(.985)}
  .b-cta.primary{background:var(--ink);color:#fff;border:1px solid var(--ink)}
  .b-cta.primary.added{background:#1a8a4a;border-color:#1a8a4a}
  .b-cta.ghost{background:#fff;color:var(--ink);border:1px solid var(--ink)}
  .b-cta.ghost:hover{background:#f5f5f7}

  .b-grid{display:grid;grid-template-columns:1fr 1fr;margin-top:34px;border:1px solid var(--line);border-radius:16px;overflow:hidden}
  .b-gi{display:flex;align-items:center;gap:12px;padding:16px 18px;direction:rtl;border-bottom:1px solid var(--line)}
  .b-gi:nth-child(odd){border-right:1px solid var(--line)}
  .b-gi:nth-last-child(-n+2){border-bottom:0}
  .b-gi .ic{color:var(--ink);flex:0 0 auto}
  .b-gi .tx{font-size:13.5px;font-weight:500}

  /* feature strip */
  .b-strip{border-top:1px solid var(--line);border-bottom:1px solid var(--line);background:#fafafb}
  .b-strip-in{display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:10px 26px;
    padding:20px 36px;direction:rtl;max-width:1100px;margin:0 auto}
  .b-strip-in .it{display:flex;align-items:center;gap:9px;font-size:14px;font-weight:500;color:var(--ink)}
  .b-strip-in .it .bd{width:5px;height:5px;border-radius:50%;background:var(--blue)}

  /* specs */
  .b-specs{max-width:1100px;margin:0 auto;padding:56px 36px}
  .b-specs h3{font-size:13px;letter-spacing:.28em;color:var(--gray);font-weight:600;direction:rtl;text-align:right}
  .b-specrow{display:grid;grid-template-columns:1fr 1fr;direction:rtl}
  .b-spec{display:flex;justify-content:space-between;align-items:center;padding:18px 4px;border-bottom:1px solid var(--line)}
  .b-spec .k{color:var(--gray);font-size:15px}
  .b-spec .v{font-weight:600;font-size:15px;direction:ltr}

  @container (max-width:980px){
    .b-hero{grid-template-columns:1fr}
    .b-stage{min-height:460px}
    .b-panel{padding:44px 28px;max-width:none}
    .b-h1{font-size:40px}
    .b-specrow{grid-template-columns:1fr}
    .b-top .nav{display:none}
  }
  @container (max-width:560px){
    .b-h1{font-size:32px}
    .b-grid{grid-template-columns:1fr}
    .b-gi:nth-child(odd){border-right:0}
    .b-gi{border-bottom:1px solid var(--line)!important}
    .b-gi:last-child{border-bottom:0!important}
    .b-actions{flex-direction:column}
    .b-top{padding:0 20px}.b-panel{padding:36px 20px}
    .b-dots{left:16px}.b-seg button{font-size:12.5px}
  }`;

  function VariationB() {
    const { PRODUCT, fmt, priceFor, monthlyFor, Stars, Icon, injectOnce } = window;
    injectOnce('pdpB-css', css);
    const [opt, setOpt] = React.useState('usbc20');
    const [color, setColor] = React.useState('white');
    const [bag, setBag] = React.useState(0);
    const [added, setAdded] = React.useState(false);
    const watermarks = { usbc20: '20W', cable1m: '1m', magsafe: 'MagSafe' };
    const curOpt = PRODUCT.options.find(o => o.id === opt);

    const addToCart = () => {
      setBag(b => b + 1); setAdded(true);
      clearTimeout(window.__bT); window.__bT = setTimeout(() => setAdded(false), 1600);
    };

    return (
      <div className="pdpB">
        <header className="b-top">
          <div className="brand"><span className="mk">T</span>Trade In Plus</div>
          <nav className="nav"><span>About</span><span>Stores</span><span>Services</span><span>Care</span><span>Shop</span></nav>
          <div className="ic">
            <button><Icon name="search" size={19}/></button>
            <button><Icon name="user" size={19}/></button>
            <button><Icon name="bag" size={19}/>{bag>0 && <span className="count">{bag}</span>}</button>
          </div>
        </header>

        <section className="b-hero">
          <div className="b-stage">
            <span className="b-tag">{PRODUCT.eyebrow}</span>
            <div className="b-water">{watermarks[opt]}</div>
            <div className="b-dots">
              {PRODUCT.colors.map(c => (
                <button key={c.id} className={'b-dot'+(color===c.id?' on':'')} style={{ background:c.hex }} onClick={()=>setColor(c.id)} aria-label={c.name}/>
              ))}
            </div>
            <img className="b-shot" src="assets/charger.png" alt="USB-C charger"/>
          </div>

          <div className="b-panel">
            <div className="b-eye">{PRODUCT.eyebrow}</div>
            <h1 className="b-h1">Chargers &amp; Cables</h1>
            <p className="b-sub">{PRODUCT.subtitle}</p>
            <div className="b-rate"><Stars value={5}/><span className="num">{PRODUCT.rating}</span><span className="cnt">· {fmt(PRODUCT.reviews)} تقييم</span></div>

            <div className="b-pricewrap">
              <div className="b-price"><span className="cur">EGP</span><span className="val">{fmt(priceFor(opt))}</span></div>
              <div className="b-mo">أو <b>EGP {fmt(monthlyFor(opt))}</b><br/>شهريًا × 24 بدون فوائد</div>
            </div>

            <div className="b-sec">
              <div className="hd"><span className="k">الخيار / Option</span><span className="v">{curOpt.name}</span></div>
              <div className="b-seg">
                {PRODUCT.options.map(o => (
                  <button key={o.id} className={opt===o.id?'on':''} onClick={()=>setOpt(o.id)}>
                    {o.name}<span className="d">{o.delta>0?`+${fmt(o.delta)}`:'الأساسي'}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="b-sec">
              <div className="hd"><span className="k">اللون / Color</span></div>
              <div className="b-pills">
                {PRODUCT.colors.map(c => (
                  <button key={c.id} className={'b-pill'+(color===c.id?' on':'')} onClick={()=>setColor(c.id)}>
                    <span className="swt" style={{ background:c.hex }}/>{c.name}
                  </button>
                ))}
              </div>
            </div>

            <div className="b-actions">
              <button className="b-cta ghost">اشترِ الآن</button>
              <button className={'b-cta primary'+(added?' added':'')} onClick={addToCart}>
                {added ? <><Icon name="check" size={20} color="#fff"/> تمت الإضافة</> : <><Icon name="cart" size={20} color="#fff"/> أضف إلى السلة</>}
              </button>
            </div>

            <div className="b-grid">
              {PRODUCT.features.map(f => (
                <div className="b-gi" key={f.icon}>
                  <span className="ic"><Icon name={f.icon} size={20}/></span>
                  <span className="tx">{f.ar}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        <div className="b-strip">
          <div className="b-strip-in">
            {PRODUCT.features.map((f,i) => (
              <div className="it" key={f.icon}><span className="bd"/>{f.ar}</div>
            ))}
          </div>
        </div>

        <section className="b-specs">
          <h3>المواصفات</h3>
          <div className="b-specrow">
            {PRODUCT.specs.map(s => (
              <div className="b-spec" key={s.k}><span className="k">{s.k}</span><span className="v">{s.v}</span></div>
            ))}
          </div>
        </section>
      </div>
    );
  }

  window.VariationB = VariationB;
})();
