/* variation-a.jsx — "Clean Classic" PDP. Refined take on the original.
   Responsive via container queries. Exports window.VariationA */

(function () {
  const css = `
  .pdpA{container-type:inline-size;background:#fff;color:#1d1d1f;
    font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Arial,sans-serif;
    -webkit-font-smoothing:antialiased;line-height:1.5;
    --ink:#1d1d1f;--gray:#6e6e73;--line:#e5e5e8;--stage:#f5f5f7;--shot:#fdfdfd;--blue:#0071e3}
  .pdpA *{box-sizing:border-box;margin:0;padding:0}
  .pdpA button{font-family:inherit;cursor:pointer}

  /* nav */
  .a-nav{display:flex;align-items:center;justify-content:space-between;height:64px;
    padding:0 40px;border-bottom:1px solid var(--line)}
  .a-nav .ico-row{display:flex;align-items:center;gap:22px;color:var(--ink)}
  .a-nav .ico-row button{background:none;border:0;color:inherit;display:flex;padding:0;opacity:.85}
  .a-nav .ico-row button:hover{opacity:1}
  .a-links{display:flex;gap:30px;font-size:14px;color:var(--gray);font-weight:500}
  .a-links span{cursor:pointer;transition:color .15s}
  .a-links span:hover{color:var(--ink)}
  .a-brand{display:flex;align-items:center;gap:10px;font-weight:800;font-size:20px;letter-spacing:-.02em}
  .a-brand .mark{width:30px;height:30px;border-radius:8px;background:var(--ink);color:#fff;
    display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:800}
  .a-bag{position:relative}
  .a-bag .count{position:absolute;top:-6px;right:-8px;background:var(--blue);color:#fff;font-size:10px;
    font-weight:700;min-width:16px;height:16px;border-radius:9px;display:flex;align-items:center;
    justify-content:center;padding:0 4px}

  /* breadcrumb */
  .a-crumb{display:flex;justify-content:flex-end;gap:8px;align-items:center;font-size:13px;color:var(--gray);
    padding:14px 40px;direction:rtl}
  .a-crumb b{color:var(--ink);font-weight:600}
  .a-crumb .sep{opacity:.4}

  /* hero */
  .a-hero{display:grid;grid-template-columns:1.05fr 1fr;gap:64px;padding:24px 40px 72px;
    max-width:1240px;margin:0 auto;align-items:start}
  .a-media{position:sticky;top:24px}
  .a-stage{background:var(--shot);border-radius:24px;aspect-ratio:1/1;display:flex;align-items:center;
    justify-content:center;overflow:hidden;position:relative}
  .a-stage img{width:72%;height:auto;filter:drop-shadow(0 30px 40px rgba(0,0,0,.10));
    transition:transform .55s cubic-bezier(.2,.7,.2,1);will-change:transform}
  .a-thumbs{display:flex;gap:12px;margin-top:14px}
  .a-thumb{flex:1;aspect-ratio:1/1;border-radius:14px;background:var(--shot);border:1px solid var(--line);
    display:flex;align-items:center;justify-content:center;overflow:hidden;transition:border-color .15s;outline:2px solid transparent;outline-offset:-2px}
  .a-thumb img{width:72%;height:auto}
  .a-thumb.on{outline-color:var(--ink);border-color:var(--ink)}

  /* info */
  .a-eyebrow{font-size:12px;letter-spacing:.32em;color:var(--gray);font-weight:600}
  .a-title{font-size:52px;line-height:1.02;letter-spacing:-.03em;font-weight:800;margin:10px 0 0;
    font-family:-apple-system,"SF Pro Display","Helvetica Neue",Helvetica,Arial,sans-serif}
  .a-sub{direction:rtl;text-align:right;color:var(--gray);font-size:18px;margin-top:14px}
  .a-rate{display:flex;align-items:center;gap:10px;margin-top:16px;direction:rtl;justify-content:flex-start}
  .a-rate .num{font-weight:600;font-size:14px}
  .a-rate .cnt{color:var(--gray);font-size:14px}

  .a-price{margin-top:28px;padding:22px 24px;border:1px solid var(--line);border-radius:18px}
  .a-price .row1{display:flex;align-items:baseline;gap:8px}
  .a-price .cur{font-size:18px;color:var(--gray);font-weight:600}
  .a-price .val{font-size:40px;font-weight:800;letter-spacing:-.02em}
  .a-price .mo{direction:rtl;text-align:right;display:flex;align-items:center;gap:8px;justify-content:flex-end;
    color:var(--gray);font-size:14px;margin-top:8px;padding-top:12px;border-top:1px solid var(--line)}
  .a-price .mo b{color:var(--ink);font-weight:700}

  .a-block{margin-top:26px}
  .a-block .lab{display:flex;justify-content:space-between;align-items:center;font-size:14px;margin-bottom:12px}
  .a-block .lab .k{color:var(--gray)}
  .a-block .lab .v{font-weight:600}
  .a-swatches{display:flex;gap:10px}
  .a-sw{width:30px;height:30px;border-radius:50%;border:1px solid var(--line);cursor:pointer;
    box-shadow:0 0 0 2px #fff inset;outline:2px solid transparent;outline-offset:2px;transition:outline-color .15s}
  .a-sw.on{outline-color:var(--ink)}
  .a-opts{display:flex;gap:10px;flex-wrap:wrap}
  .a-opt{flex:1;min-width:120px;border:1px solid var(--line);border-radius:14px;padding:12px 14px;background:#fff;
    text-align:left;transition:border-color .15s,box-shadow .15s}
  .a-opt:hover{border-color:#bcbcc2}
  .a-opt.on{border-color:var(--ink);box-shadow:0 0 0 1px var(--ink)}
  .a-opt .on-name{font-weight:600;font-size:15px}
  .a-opt .on-note{font-size:12px;color:var(--gray);margin-top:3px;direction:rtl;text-align:left}
  .a-opt .on-delta{font-size:12px;color:var(--blue);font-weight:600;margin-top:6px}

  .a-buy{display:flex;flex-direction:column;gap:12px;margin-top:28px}
  .a-cta{display:flex;align-items:center;justify-content:center;gap:10px;height:54px;border-radius:14px;
    font-size:16px;font-weight:600;border:1px solid var(--ink);transition:transform .12s,background .15s,color .15s}
  .a-cta:active{transform:scale(.985)}
  .a-cta.primary{background:var(--ink);color:#fff}
  .a-cta.primary.added{background:#1a8a4a;border-color:#1a8a4a}
  .a-cta.ghost{background:#fff;color:var(--ink)}
  .a-cta.ghost:hover{background:#f5f5f7}
  .a-qtyrow{display:flex;align-items:center;gap:14px}
  .a-qty{display:flex;align-items:center;border:1px solid var(--line);border-radius:14px;height:54px;overflow:hidden}
  .a-qty button{width:46px;height:100%;background:#fff;border:0;display:flex;align-items:center;justify-content:center;color:var(--ink)}
  .a-qty button:hover{background:#f5f5f7}
  .a-qty .n{min-width:34px;text-align:center;font-weight:600;font-size:16px}

  .a-trust{margin-top:30px;border-top:1px solid var(--line)}
  .a-trust .ti{display:flex;align-items:center;gap:14px;padding:15px 2px;border-bottom:1px solid var(--line);direction:rtl}
  .a-trust .ti .ic{width:38px;height:38px;border-radius:10px;background:var(--stage);display:flex;
    align-items:center;justify-content:center;flex:0 0 auto;color:var(--ink)}
  .a-trust .ti .tx{font-size:15px;font-weight:500}

  /* features band */
  .a-band{background:var(--stage);padding:56px 40px}
  .a-band-in{max-width:1240px;margin:0 auto}
  .a-band h2{font-size:13px;letter-spacing:.28em;color:var(--gray);text-align:center;font-weight:600}
  .a-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-top:28px}
  .a-card{background:#fff;border-radius:18px;padding:26px 22px}
  .a-card .ic{width:44px;height:44px;border-radius:12px;background:var(--stage);display:flex;
    align-items:center;justify-content:center;color:var(--ink);margin-bottom:16px}
  .a-card .ct{font-weight:600;font-size:16px}
  .a-card .cd{direction:rtl;color:var(--gray);font-size:13px;margin-top:6px}

  @container (max-width:900px){
    .a-hero{grid-template-columns:1fr;gap:36px;padding:20px 22px 60px}
    .a-media{position:static}
    .a-title{font-size:40px}
    .a-cards{grid-template-columns:repeat(2,1fr)}
    .a-nav{padding:0 22px}
    .a-band{padding:48px 22px}
  }
  @container (max-width:560px){
    .a-links,.a-crumb{display:none}
    .a-title{font-size:34px}
    .a-opt{min-width:100%}
    .a-cards{grid-template-columns:1fr}
    .a-nav{height:56px}
  }`;

  function VariationA() {
    const { PRODUCT, fmt, priceFor, monthlyFor, Stars, Icon, injectOnce } = window;
    injectOnce('pdpA-css', css);
    const [opt, setOpt] = React.useState('usbc20');
    const [color, setColor] = React.useState('white');
    const [qty, setQty] = React.useState(1);
    const [thumb, setThumb] = React.useState(0);
    const [bag, setBag] = React.useState(0);
    const [added, setAdded] = React.useState(false);
    const views = [
      { t: 'scale(1) translate(0,0)',        lab: 'كامل' },
      { t: 'scale(2.1) translate(0%,-22%)',  lab: 'الأطراف' },
      { t: 'scale(1.9) translate(0%,16%)',   lab: 'الجسم' },
      { t: 'scale(1.8) translate(-16%,2%)',  lab: 'جانبي' },
    ];

    const addToCart = () => {
      setBag(b => b + qty);
      setAdded(true);
      clearTimeout(window.__aT); window.__aT = setTimeout(() => setAdded(false), 1600);
    };

    return (
      <div className="pdpA">
        <nav className="a-nav">
          <div className="ico-row">
            <button title="الوضع الليلي"><Icon name="moon" size={20}/></button>
            <button title="حسابي"><Icon name="user" size={20}/></button>
            <button className="a-bag" title="السلة"><Icon name="bag" size={20}/>{bag>0 && <span className="count">{bag}</span>}</button>
            <button title="بحث"><Icon name="search" size={20}/></button>
          </div>
          <div className="a-links">
            <span>About</span><span>Stores</span><span>Business</span><span>Services</span><span>Shop</span>
          </div>
          <div className="a-brand"><span className="mark">T</span>Trade In Plus</div>
        </nav>

        <div className="a-crumb">
          <b>Chargers &amp; Cables</b><span className="sep">‹</span><span>Accessories</span><span className="sep">‹</span><span>الرئيسية</span>
        </div>

        <main className="a-hero">
          <div className="a-media">
            <div className="a-stage">
              <img src="assets/charger.png" alt="USB-C charger" style={{ transform: views[thumb].t }} />
            </div>
            <div className="a-thumbs">
              {views.map((v, i) => (
                <button key={i} className={'a-thumb' + (thumb===i?' on':'')} onClick={() => setThumb(i)} aria-label={v.lab}>
                  <img src="assets/charger.png" alt="" style={{ transform: v.t }} />
                </button>
              ))}
            </div>
          </div>

          <div className="a-info">
            <div className="a-eyebrow">{PRODUCT.eyebrow}</div>
            <h1 className="a-title">Chargers<br/>&amp; Cables</h1>
            <p className="a-sub">{PRODUCT.subtitle}</p>
            <div className="a-rate">
              <Stars value={5} /><span className="num">{PRODUCT.rating}</span>
              <span className="cnt">· {fmt(PRODUCT.reviews)} تقييم</span>
            </div>

            <div className="a-price">
              <div className="row1"><span className="cur">EGP</span><span className="val">{fmt(priceFor(opt))}</span></div>
              <div className="mo"><Icon name="card" size={18} color="#6e6e73"/><span>أو <b>EGP {fmt(monthlyFor(opt))}</b> شهريًا لمدة 24 شهر بدون فوائد</span></div>
            </div>

            <div className="a-block">
              <div className="lab"><span className="k">اللون / Color</span><span className="v">{PRODUCT.colors.find(c=>c.id===color).name}</span></div>
              <div className="a-swatches">
                {PRODUCT.colors.map(c => (
                  <button key={c.id} className={'a-sw'+(color===c.id?' on':'')} style={{ background: c.hex }} onClick={() => setColor(c.id)} aria-label={c.name}/>
                ))}
              </div>
            </div>

            <div className="a-block">
              <div className="lab"><span className="k">الخيار / Option</span></div>
              <div className="a-opts">
                {PRODUCT.options.map(o => (
                  <button key={o.id} className={'a-opt'+(opt===o.id?' on':'')} onClick={() => setOpt(o.id)}>
                    <div className="on-name">{o.name}</div>
                    <div className="on-note">{o.note}</div>
                    {o.delta>0 && <div className="on-delta">+{fmt(o.delta)} EGP</div>}
                  </button>
                ))}
              </div>
            </div>

            <div className="a-buy">
              <div className="a-qtyrow">
                <div className="a-qty">
                  <button onClick={() => setQty(q => Math.max(1, q-1))}><Icon name="minus" size={16}/></button>
                  <span className="n">{qty}</span>
                  <button onClick={() => setQty(q => q+1)}><Icon name="plus" size={16}/></button>
                </div>
                <button className={'a-cta primary'+(added?' added':'')} style={{ flex:1 }} onClick={addToCart}>
                  {added ? <><Icon name="check" size={20} color="#fff"/> تمت الإضافة</> : <><Icon name="cart" size={20} color="#fff"/> أضف إلى السلة</>}
                </button>
              </div>
              <button className="a-cta ghost">اشترِ الآن</button>
            </div>

            <div className="a-trust">
              {PRODUCT.features.map(f => (
                <div className="ti" key={f.icon}>
                  <span className="ic"><Icon name={f.icon} size={20}/></span>
                  <span className="tx">{f.ar}</span>
                </div>
              ))}
            </div>
          </div>
        </main>

        <section className="a-band">
          <div className="a-band-in">
            <h2>ليه تشتري من Trade In Plus</h2>
            <div className="a-cards">
              {PRODUCT.features.map(f => (
                <div className="a-card" key={f.icon}>
                  <span className="ic"><Icon name={f.icon} size={22}/></span>
                  <div className="ct">{f.en}</div>
                  <div className="cd">{f.ar}</div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    );
  }

  window.VariationA = VariationA;
})();
